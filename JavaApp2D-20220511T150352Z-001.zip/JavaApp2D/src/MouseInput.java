
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class MouseInput implements MouseListener{

    GamePanel gp;
    public MouseInput(GamePanel gp){
        this.gp = gp;
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public void mousePressed(MouseEvent e) {
        /*public Rectangle playButton = new Rectangle(720,150,120,50);
        public Rectangle introButton = new Rectangle(720,250,120,50);
        public Rectangle creditButton = new Rectangle(720,350,120,50);
        public Rectangle exitButton = new Rectangle(720,450,120,50);*/
        int mx = e.getX();
        int my = e.getY();
        
        
        
        if(GamePanel.State=="Menu")
        {
            if(mx>=720 && mx<=840)
            {
                if(my>=150 && my<=200)
                {
                    gp.restart();
                    gp.State = "level1";
                    //new GamePanel().isdead = false;
                    //new GamePanel().check1(GamePanel.State,new GamePanel().isdead);
                    System.out.println("restarted1");
                    
                }
                else if(my>=250 && my<=300)
                {
                    gp.restart();
                    gp.State = "level2";
                    System.out.println("restarted");
                    //new GamePanel().isdead2 = false;
                    //new GamePanel().check2(GamePanel.State,new GamePanel().isdead2);
                }
                else if(my>=350 && my<=400)
                {
                    //GamePanel.State = "start";
                }
                else if(my>=450 && my<=500)
                {
                    //GamePanel.State = "start";
                    System.exit(1);
                }
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
