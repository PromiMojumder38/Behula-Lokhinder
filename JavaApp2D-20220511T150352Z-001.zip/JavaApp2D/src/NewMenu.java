
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;


public class NewMenu {
    public Rectangle playButton = new Rectangle(720,150,120,50);
    public Rectangle introButton = new Rectangle(720,250,120,50);
    public Rectangle creditButton = new Rectangle(720,350,120,50);
    public Rectangle exitButton = new Rectangle(720,450,120,50);
    
    public void render(Graphics g){
        //this.MouseInput();
        Graphics2D g2 = (Graphics2D)g;
        Font fnt0 = new Font("arial",Font.BOLD,50);
        g2.setFont(fnt0);
        g2.setColor(Color.red);
        g2.drawString("O Behula", 600, 100);
        
        Font fnt1 = new Font("arial",Font.BOLD,30);
        g2.setFont(fnt1);
        g2.setColor(Color.white);
        g2.drawString("Play", playButton.x + 19, playButton.y + 30);
        g2.draw(playButton);
        
        g2.drawString("Intro", introButton.x + 19, introButton.y + 30);
        g2.draw(introButton);
        
        g2.drawString("Credit", creditButton.x + 19, creditButton.y + 30);
        g2.draw(creditButton);
        
        g2.drawString("Exit", exitButton.x + 19, exitButton.y + 30);
        g2.draw(exitButton);
    }
}
