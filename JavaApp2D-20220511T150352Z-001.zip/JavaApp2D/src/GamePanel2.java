

/*
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;


public class GamePanel extends JPanel implements Runnable, ActionListener{
    
    private int space;
    private int space2;
    private int speed;
    private int width=100;
    private int height = 100;
    private int WIDTH = 1200;
    private int HEIGHT = 750;
    private int move = 20, move2 = 20, count = 0, count2 = 0;
    
    boolean isdead = false;
    boolean isdead2 = false;
    
    int z = 0;
    int FPS = 60;
    
    private BufferedImage back1,player,behula1,behula2,behula3,behula4,stone,water;
    public static Rectangle playerd;
    public static Rectangle vela; 
    public static Rectangle falg;
    private ArrayList<Rectangle> stones;
    private ArrayList<Rectangle> stones2;
    private Random rand;
    Timer t;
    public static String State = "level1";
    Thread gameThread;
    
    NewMenu nmenu = new NewMenu();
    Level2 level2 = new Level2();
    KeyInput keyh = new KeyInput();
    Player playerr = new Player(this,keyh);
    Player2 playerr2 = new Player2(this,keyh);
    
    public GamePanel() {
        //restart();
        init();
    }
    /*public void restart(){
                stones.clear();
                stones2.clear();
                playerr = new Player(this,keyh);
                playerr2 = new Player2(this,keyh);
                
        }*/
    /*npublic void init() {
        
        try {
            back1 = ImageIO.read(new File("C:\\Users\\ASUS\\Desktop\\skybg1.png"));
            behula1 = ImageIO.read(new File("F:\\New Folder (2)\\JavaApp2D\\src\\chobigula\\b1.png"));
            behula2 = ImageIO.read(new File("F:\\New Folder (2)\\JavaApp2D\\src\\chobigula\\b2.png"));
            behula3 = ImageIO.read(new File("F:\\New Folder (2)\\JavaApp2D\\src\\chobigula\\b3.png"));
            behula4 = ImageIO.read(new File("F:\\New Folder (2)\\JavaApp2D\\src\\chobigula\\b4.png"));
            stone = ImageIO.read(new File("F:\\New Folder (2)\\JavaApp2D\\src\\chobigula\\stone.png"));
            water = ImageIO.read(new File("C:\\Users\\ASUS\\Desktop\\watervela.gif"));
            
        } catch (IOException ex) {
            Logger.getLogger(GamePanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        //this.addMouseListener(new MouseInput());
        this.setPreferredSize(new Dimension(WIDTH,HEIGHT));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyh);
        this.setFocusable(true);
        this.addMouseListener(new MouseInput());
        
        t = new Timer(20,this);
        
        space = 1000;
        space2 = 200;
        speed = 2;
        rand = new Random();
        stones = new ArrayList<Rectangle>();
        //playerd = new Rectangle(WIDTH/2-90,HEIGHT-170,80,80);
        playerd = new Rectangle(playerr.x,playerr.y,130,200);
        
        stones2 = new ArrayList<Rectangle>();
        vela = new Rectangle(WIDTH/2-50, HEIGHT-100, 100, 100);
        /*addstones(true);
        addstones(true);
        addstones(true);
        addstones(true);
        addstones(true);
        addstones(true);
        addstones(true);*/
        
        
        
        /*nt.start();
        
    }
    
    public void addstones(boolean first){
        //int positionx = rand.nextInt()%2;
        int x=0;
        int y=0;
        int sp = 500+rand.nextInt()%300; 
        
        int Width=width;
        int Height=height;
        
        /*if(positionx==0){
            x = WIDTH/2-90;
        }
        else {
            x = WIDTH/2+10;
        }*/
        /*if(first){
            //stones.add(new Rectangle(x,y-100-(stones.size()*space),Width,Height));
            stones.add(new Rectangle(stones.size()*space+ sp,550,50,50));//Height,Width));//x,y-100-(stones.size()*space),Width,Height));
        }
        else {
            stones.add(new Rectangle(stones.get(stones.size()-1).y,y + space,50,50));//Width,Height));
        }
        
        /*int spac = 300;
        int wid = 100;
        int hi = 50 ;//+ rand.nextInt(300);
        
        /*if(first)
        {
            stones.add(new Rectangle(WIDTH + wid + stones.size()*300, HEIGHT - hi - 120, wid,hi));
            stones.add(new Rectangle(WIDTH + wid + (stones.size() - 1)*300, 0, wid, HEIGHT - hi - spac));
        }
        else
        {
            stones.add(new Rectangle(stones.get(stones.size() - 1).x + 600, HEIGHT - hi-120, wid, hi));
            stones.add(new Rectangle(stones.get(stones.size() - 1).x, 0, wid, HEIGHT - hi - spac));
        }
        
        if(first)
        {
            stones.add(new Rectangle(WIDTH -600 + wid + stones.size()*200, hi, wid,hi));
            stones.add(new Rectangle(WIDTH -600 + wid + (stones.size() - 1)*200, 600, wid, hi));
        }
        else
        {
            stones.add(new Rectangle(stones.get(stones.size() - 1).y + 600, hi, wid, hi));
            stones.add(new Rectangle(stones.get(stones.size() - 1).y, 0, wid, hi ));
        }
        */
    /*n}
    /*n
    public void addstones2(boolean second)
    {
        int positionx = rand.nextInt()%4  ;
        int x = 0;
        int y = 0;
        int Width = width;
        int Height = height;
        if(positionx == 0){
            x = 150;
        }
        else if(positionx == 1){
            x = 450;
        }
        
        else if(positionx == 2){
            x = 750;
        }
        else {
            x = 1050;
        }
        if(second){
            stones2.add(new Rectangle(x, y-100-(stones2.size()*space2), Width, Height));
        }
        else {
            stones2.add(new Rectangle(x,stones2.get(stones2.size()-1).y-300,Width,Height));
        }
    }
    
    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {n*/
        /*double drawInterval = 1000000000/FPS;
        double nextDrawTime = System.nanoTime() + drawInterval;
        
        while(gameThread != null) {
            
            update();
            repaint();
           
            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime/1000000;
                
                if(remainingTime < 0){
                    remainingTime = 0;
                }
                Thread.sleep((long)remainingTime);
                nextDrawTime += drawInterval;
            } 
            catch (InterruptedException e) {
                    e.printStackTrace();
            }
        }*/
    /*n
        double drawInterval = 1000000000/FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;
        
        while(gameThread != null)
        {
            currentTime = System.nanoTime();
            
            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;
            
            if(delta >= 1) {
                update();
                repaint();
                delta--;
                drawCount++;
            }
            
            if(timer >= 1000000000) {
                drawCount = 0;
                timer = 0;
            }
        }
    }
    
    public void update() {
        /*if(State == "level1")
        //{
            if(keyh.uppressed==true){
                playerd.y -= speed;
            }
            else if(keyh.downpressed==true){
                playerd.y += speed;
            }
            else if(keyh.leftpressed==true){
                playerd.x -= speed;
            }
            else if(keyh.rightpressed==true){
                playerd.x += speed;
            }
            
            else if(keyh.escpressed == true){
                State = "Menu";
            }
            
            else if(keyh.spacepressed == true){
                playerd.y -= speed;
            }
        //}*/
        /*nif(State == "level1"){
            playerr.update();
        }
        
        if(State == "level2"){
            playerr2.update();
        }
        
        repaint();
    }
    
    public void paintComponent(Graphics g) {
        
        switch(State){
            
            case "level1":
                gameUpdate1(g);
                break;
             
            case "level2":
                gameUpdate2(g);
                break;
                
            case "Menu":
                super.paintComponent(g);
                //stones.clear();
                //stones2.clear();
                nmenu.render(g);
                break;
                
        }
        
        
    }
    
    public void gameUpdate1(Graphics g){
        super.paintComponent(g);
        Graphics2D gp = (Graphics2D)g;            
        gp.setColor(Color.white);
        gp.fillRect(0, 650, WIDTH, 200);
        gp.drawImage(back1,0,0,this);
        gp.setColor(Color.orange);
        gp.fillRect(0, 600, WIDTH, 50);
        //gp.setColor(Color.green.darker());
        //gp.fillRect(playerd.x, playerd.y, playerd.width, playerd.height);

        gp.drawImage(player,playerr.x,playerr.y,this);
        //playerr.draw(gp);
        //gp.setColor(Color.white);
        //gp.fillRect(WIDTH/2-100, 0, 200, HEIGHT);
        //gp.setColor(Color.red);
        //gp.fillRect(100, 400, 130, 200);
        //g2.drawLine(WIDTH/2,0,WIDTH/2, HEIGHT);
        gp.setColor(Color.black);

        for(Rectangle rect: stones){
            //gp.drawImage(stone,rect.x, rect.y, this);
            gp.setColor(Color.green.darker());
            gp.fillRect(rect.x, rect.y, rect.width, rect.height);
        }
        gp.dispose();
        
        int b = 0;
        while(b<10 && State =="level1"){
            addstones(true);
            b++;
        }
    }
    
    public void gameUpdate2(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D gp2 = (Graphics2D)g;            
        gp2.setColor(Color.cyan);
        gp2.fillRect(0,0,WIDTH,HEIGHT);
        gp2.drawImage(water,0,0,this);
        //g.setColor(Color.orange);
        //g.fillRect(WIDTH/2-100,0,200,HEIGHT);
        gp2.setColor(Color.red);
        gp2.fillRect(vela.x,vela.y,vela.width,vela.height);
        gp2.setColor(Color.blue);
        gp2.drawLine(WIDTH/2, 0, WIDTH/2, HEIGHT);
        gp2.setColor(Color.MAGENTA);
        for(Rectangle rect2:stones2) {
            gp2.fillRect(rect2.x, rect2.y, rect2.width, rect2.height);
        }

        int c = 0;
        while(c<30 && State=="level2"){
            addstones2(true);
            c++;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        z++;
        switch(z)
        {
            case 1:
            {
                player = behula1;
                break;
            }
            
            case 10:
            {
                player = behula2;
                break;
            }
            
            case 20:
            {
                player = behula3;
                break;
            }
            
            case 30:
            {
                player = behula4;
                break;
            }
               
        }
        if(z==40)
        {
            z=0;
        }
        
        
        int speed = 7;
        /*ticks++;
        
        for(int i =0; i<stones.size(); i++)
        {
            Rectangle stone = stones.get(i);
            //stone.x -= speed;
            if(stone.x + stone.width < 0)
            {
                stones.remove(stone);
                if(stone.y ==0)
                {
                    addstones(false);
                }
            }
        }
        /*if(ticks%2==0 && yMotion<15)
        {
            yMotion+=2;
            //playerd += yMotion;
        }*/
        /*Rectangle rect;
        for(int i =0; i<stones.size(); i++){
            rect = stones.get(i);
            rect.x -= speed;
        }
        
        repaint();
        */
        /*nRectangle rect;
        count++;
        for(int i = 0; i < stones.size(); i++)
        {
            rect=stones.get(i);
            if(count % 100 == 0)
            {
                speed++;
                if(move < 50) move+=10;
            }
            rect.x -= speed;
        }
        for(Rectangle r:stones)
        {
            if(r.intersects(playerd)){
                //playerd.y = r.y + height;
                //isdead = true;
                //State = "level2";
            }
            /*if(playerr.x + 130 == r.x){
                State = "Menu";
            }*/
        /*}
        /*nfor(int i = 0; i <stones.size(); i++)
        {
            rect=stones.get(i);
            if(isdead == true)//rect.y+rect.height>HEIGHT)
            {
                stones.remove(rect);
                addstones(false);
            }
        }
        
        //for level2
        Rectangle rect2;
        count2++;
        for(int i = 0; i < stones2.size(); i++)
        {
            rect2=stones2.get(i);
            if(count2 % 1000 == 0)
            {
                speed++;
                if(move2 < 50) move2+=10;
            }
            rect2.y+=speed;
        }
        for(Rectangle r:stones2)
        {
            if(r.intersects(vela)) {
                //isdead2 = true;
                //State = "Menu";
            }
        }
        for(int i = 0; i <stones2.size(); i++)
        {
            rect2=stones2.get(i);
            if(isdead2==true)//rect2.y+rect2.height>HEIGHT)
            {
                stones2.remove(rect2);
                addstones2(false);
            }
        }
        
        repaint();
    }
}
*/